const PORT = 3000;

const DB_URL = 'mongodb://localhost:27017/wizard-creatures';

const SECRET = '6815bd59-e67d-4aab-acf3-6be1df3d443f';

module.exports = {
    PORT,
    DB_URL,
    SECRET
};